package com.example.dreamday;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DreamdayApplication {

	public static void main(String[] args) {
		SpringApplication.run(DreamdayApplication.class, args);
	}

}
